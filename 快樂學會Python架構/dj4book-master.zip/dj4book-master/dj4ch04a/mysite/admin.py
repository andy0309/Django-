from django.contrib import admin
from mysite.models import NewTable, Product

admin.site.register(NewTable)
admin.site.register(Product)


